﻿    using Microsoft.AspNetCore.Components.Forms;
    using Microsoft.AspNetCore.Components.WebAssembly.Http;
    using System.Net.Http.Json;
    using Training_Management_System_UI.Models.Training;
    using static Training_Management_System_UI.Pages.CreateTraining;

    namespace Training_Management_System_UI.Services
    {
        public class TrainingService
        {
            private readonly HttpClient _http;

            public TrainingService(HttpClient http)
            {
                _http = http;
            }

            public async Task<List<TrainingResponse>> GetAllTrainingsAsync()
            {
                try
                {
                    var result = await _http.GetFromJsonAsync<List<TrainingResponse>>("api/training/trainings");
                    return result ?? new List<TrainingResponse>();
                }
                catch (Exception)
                {
                    return new List<TrainingResponse>();
                }
            }

            // CREATE TRAINING
            public async Task<(bool Success, string Message)> CreateTrainingAsync(
        string title,
        string description,
        int durationInDays,
        Guid createdByUserId,
        List<StagedFile> files,         // ← changed from IBrowserFile
        List<AddAttendeeItem> attendees)
            {
                try
                {
                    var form = new MultipartFormDataContent();

                    form.Add(new StringContent(title), "Title");
                    form.Add(new StringContent(description), "Description");
                    form.Add(new StringContent(durationInDays.ToString()), "TrainingDurationInDays");
                    form.Add(new StringContent(createdByUserId.ToString()), "CreatedByUserId");

                    for (int i = 0; i < attendees.Count; i++)
                    {
                        form.Add(new StringContent(attendees[i].FullName), $"Attendees[{i}].FullName");
                        form.Add(new StringContent(attendees[i].Email), $"Attendees[{i}].Email");
                        form.Add(new StringContent(attendees[i].Contact), $"Attendees[{i}].Contact");
                    }

                    // ← now uses byte[] instead of IBrowserFile
                    for (int i = 0; i < files.Count; i++)
                    {
                        var fileContent = new ByteArrayContent(files[i].Data);
                        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(files[i].ContentType);
                        form.Add(fileContent, $"Materials[{i}].File", files[i].Name);
                        form.Add(new StringContent("false"), $"Materials[{i}].IsExternal");
                    }

                    var request = new HttpRequestMessage(HttpMethod.Post, "api/training/create");
                    request.SetBrowserRequestCredentials(BrowserRequestCredentials.Include);
                    request.Content = form;

                    var response = await _http.SendAsync(request);
                    var responseMessage = await response.Content.ReadAsStringAsync();

                    if (response.IsSuccessStatusCode)
                        return (true, "Training created successfully!");

                    return (false, responseMessage);
                }
                catch (Exception ex)
                {
                    return (false, ex.Message);
                }
            }

            public class AddAttendeeItem
            {
                public string FullName { get; set; } = string.Empty;
                public string Email { get; set; } = string.Empty;
                public string Contact { get; set; } = string.Empty;
            }

            public class StagedFile
            {
                public string Name { get; set; } = string.Empty;
                public string ContentType { get; set; } = string.Empty;
                public long Size { get; set; }
                public byte[] Data { get; set; } = Array.Empty<byte>();
            }
        }
    }